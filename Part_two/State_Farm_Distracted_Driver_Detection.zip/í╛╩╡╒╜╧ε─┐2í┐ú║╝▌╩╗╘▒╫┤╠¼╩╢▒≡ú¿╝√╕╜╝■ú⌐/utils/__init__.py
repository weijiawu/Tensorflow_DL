# encoding: utf-8
"""
@author: yxluo
@contact: nihaoseeing@gmail.com
"""
from .get_submission_result import predict_result
from .test_data import read_test
